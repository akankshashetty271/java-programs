import java.util.*;

class JavaString
{
	public static void main(String arg[])
	{
		Scanner sobj = new Scanner(System.in);
		
		System.out.println("Please enter string");
		
		String str = sobj.nextLine();
		
		System.out.println("Entered string is : "+str);
	}
}