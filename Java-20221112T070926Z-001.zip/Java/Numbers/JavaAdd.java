
class JavaAdd
{
	public static void main(String arg[])
	{
		int ans = 0;
		int no1 = 10, no2 = 20;
		ans = no1 + no2;
		System.out.println("Addition is : "+ans);
	}
}